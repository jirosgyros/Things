# BOF Runner Framework

This tool emulates the memory, syscall, injection, and behavioral footprint of Cobalt Strike BOFs to help test detection logic and hunt real red team beacons.

---

## Installation

### Requirements:
- CMake >= 3.12
- GCC/Clang (or Mingw for cross-compiling on Linux)
- Python 3.8+ (for Sigma generator)
- Windows system for testing BOF injection behavior

---

## Build Instructions

### On Windows (with MSVC or Mingw):
```bash
mkdir build
cd build
cmake ..
cmake --build . --config Release
```

### On Linux (cross-compiling):
```bash
sudo apt install gcc-mingw-w64 cmake
mkdir build
cd build
x86_64-w64-mingw32-cmake ..
make
```

---

## Usage Examples

### Run BOF Locally:
```bash
./bof_runner_framework test_bof.o "arg1" "arg2"
```

### Inject BOF into Remote Process:
```c
inject_parsed_bof_to_process("notepad.exe", "my_bof.o", args, argc);
```

### Unhook Security Controls:
```c
unhook_security();
```

### Generate Sigma Rule (Python):
```python
from sigma_generator import generate_sigma_rule

print(generate_sigma_rule(
    "Memory Injection",
    "Detects RWX memory and remote threads",
    {"Image": "C:\\Windows\\System32\\rundll32.exe", "CommandLine|contains": "VirtualAlloc"}
))
```

---

## Key Features

- BOF ELF `.o` parsing and in-memory loading
- Beacon-style `datap` argument simulation
- Remote process injection with syscall stubs
- RWX memory + thread creation mimicking Beacon
- AMSI and ETW unhooking
- Sigma rule generation engine
- Symbol resolver and winapi hash-ready

---

## Notes

For full syscall support, integrate with `SysWhispers2` and replace WinAPI wrappers with syscall stubs.