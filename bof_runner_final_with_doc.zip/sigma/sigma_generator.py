import yaml

def generate_sigma_rule(signature_name, description, conditions):
    rule = {
        "title": signature_name,
        "id": "generated-" + signature_name.lower().replace(" ", "-"),
        "description": description,
        "status": "experimental",
        "logsource": {
            "category": "process_creation",
            "product": "windows"
        },
        "detection": {
            "selection": conditions,
            "condition": "selection"
        },
        "level": "high"
    }
    return yaml.dump(rule, sort_keys=False)