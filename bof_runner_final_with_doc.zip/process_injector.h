#ifndef PROCESS_INJECTOR_H
#define PROCESS_INJECTOR_H

int inject_to_process(const char *target_proc, void *payload, size_t size);

#endif