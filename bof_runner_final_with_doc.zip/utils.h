#ifndef UTILS_H
#define UTILS_H

void print_hex(const unsigned char *data, size_t len);

#endif