#ifndef BEACON_APIS_H
#define BEACON_APIS_H

void datap_init(int argc, char **argv);
char *datap_str(int index);
int datap_int(int index);

#endif