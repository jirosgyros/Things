#ifndef RELOCATOR_H
#define RELOCATOR_H

void apply_relocations(unsigned char *base, size_t size);

#endif