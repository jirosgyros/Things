#include <stdio.h>
#include <string.h>
#include "bof_loader.h"

void print_help(const char *prog) {
    printf("Usage: %s <bof.o> [args...]\n", prog);
    printf("Example: %s test_bof.o arg1 arg2\n", prog);
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        print_help(argv[0]);
        return 1;
    }

    const char *bof_path = argv[1];
    char **args = argc > 2 ? &argv[2] : NULL;
    int arg_count = argc - 2;

    printf("[*] Running BOF: %s with %d arguments\n", bof_path, arg_count);

    if (!load_and_execute_bof(bof_path, args, arg_count)) {
        fprintf(stderr, "[-] BOF execution failed.\n");
        return 1;
    }

    return 0;
}