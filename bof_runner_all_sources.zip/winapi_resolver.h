#ifndef WINAPI_RESOLVER_H
#define WINAPI_RESOLVER_H

void *resolve_api(const char *dll, const char *func);

#endif