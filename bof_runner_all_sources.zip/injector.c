#include <windows.h>
#include <stdio.h>

int inject_and_run(void *payload, size_t size) {
    LPVOID mem = VirtualAlloc(NULL, size, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
    if (!mem) {
        printf("[-] Allocation failed.\n");
        return 0;
    }

    memcpy(mem, payload, size);
    ((void(*)())mem)();
    VirtualFree(mem, 0, MEM_RELEASE);
    return 1;
}