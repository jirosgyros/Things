#include <stdio.h>
#include <stdint.h>
#include <windows.h>
#include "relocator.h"

typedef struct {
    uint32_t r_offset;
    uint32_t r_info;
} Elf32_Rel;

#define ELF32_R_SYM(i) ((i) >> 8)
#define ELF32_R_TYPE(i) ((unsigned char)(i))

#define R_386_PC32 2
#define R_386_32   1

void apply_relocations(unsigned char *base, size_t size) {
    Elf32_Rel *relocs = (Elf32_Rel *)(base + size - 64);
    size_t num_relocs = 4;

    for (size_t i = 0; i < num_relocs; ++i) {
        uint32_t offset = relocs[i].r_offset;
        uint32_t *patch = (uint32_t *)(base + offset);
        *patch += (uint32_t)(uintptr_t)base;
    }

    printf("[*] Relocation patching completed\n");
}