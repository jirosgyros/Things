#ifndef BOF_LOADER_H
#define BOF_LOADER_H

#include <stdbool.h>

bool load_and_execute_bof(const char *filepath, char **args, int argc);

#endif