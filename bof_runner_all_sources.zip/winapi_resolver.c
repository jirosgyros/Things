#include <windows.h>
#include <stdio.h>
#include "winapi_resolver.h"

void *resolve_api(const char *dll, const char *func) {
    HMODULE mod = LoadLibraryA(dll);
    if (!mod) {
        printf("[-] Failed to load DLL: %s\n", dll);
        return NULL;
    }

    void *addr = GetProcAddress(mod, func);
    if (!addr) {
        printf("[-] Failed to resolve function: %s\n", func);
    }
    return addr;
}