#include <windows.h>
#include <evntprov.h>
#include <stdio.h>

void simulate_etw_event(const char *msg) {
    printf("[ETW] Simulated Event: %s\n", msg);
}