#ifndef DIRECT_INJECTOR_H
#define DIRECT_INJECTOR_H

int inject_parsed_bof_to_process(const char *proc_name, const char *bof_path, char **args, int argc);

#endif