#ifndef INJECTOR_H
#define INJECTOR_H

int inject_and_run(void *payload, size_t size);

#endif