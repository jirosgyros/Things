#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>
#include "bof_loader.h"
#include "beacon_apis.h"

typedef struct {
    unsigned char e_ident[16];
    uint16_t e_type;
    uint16_t e_machine;
    uint32_t e_version;
    uint32_t e_entry;
    uint32_t e_phoff;
    uint32_t e_shoff;
    uint32_t e_flags;
    uint16_t e_ehsize;
    uint16_t e_phentsize;
    uint16_t e_phnum;
    uint16_t e_shentsize;
    uint16_t e_shnum;
    uint16_t e_shstrndx;
} Elf32_Ehdr;

typedef struct {
    uint32_t sh_name;
    uint32_t sh_type;
    uint32_t sh_flags;
    uint32_t sh_addr;
    uint32_t sh_offset;
    uint32_t sh_size;
    uint32_t sh_link;
    uint32_t sh_info;
    uint32_t sh_addralign;
    uint32_t sh_entsize;
} Elf32_Shdr;

bool load_and_execute_bof(const char *filepath, char **args, int argc) {
    FILE *file = fopen(filepath, "rb");
    if (!file) {
        perror("fopen");
        return false;
    }

    fseek(file, 0, SEEK_END);
    long size = ftell(file);
    rewind(file);

    unsigned char *buffer = malloc(size);
    if (!buffer) {
        fclose(file);
        return false;
    }

    fread(buffer, 1, size, file);
    fclose(file);

    Elf32_Ehdr *ehdr = (Elf32_Ehdr *)buffer;
    if (ehdr->e_ident[0] != 0x7f || strncmp((char*)&ehdr->e_ident[1], "ELF", 3) != 0) {
        fprintf(stderr, "[-] Invalid ELF\n");
        free(buffer);
        return false;
    }

    Elf32_Shdr *shdrs = (Elf32_Shdr *)(buffer + ehdr->e_shoff);
    LPVOID exec_mem = VirtualAlloc(NULL, size, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
    if (!exec_mem) {
        perror("VirtualAlloc");
        free(buffer);
        return false;
    }

    for (int i = 0; i < ehdr->e_shnum; i++) {
        if (shdrs[i].sh_size > 0 && shdrs[i].sh_type != 8) {
            memcpy((char *)exec_mem + shdrs[i].sh_addr, buffer + shdrs[i].sh_offset, shdrs[i].sh_size);
        }
    }

    datap_init(argc, args);
    void (*entry)() = (void (*)())((char *)exec_mem + ehdr->e_entry);
    entry();

    VirtualFree(exec_mem, 0, MEM_RELEASE);
    free(buffer);
    return true;
}