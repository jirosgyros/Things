#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "beacon_apis.h"

static int global_argc = 0;
static char **global_argv = NULL;

void datap_init(int argc, char **argv) {
    global_argc = argc;
    global_argv = argv;
}

char *datap_str(int index) {
    if (index < 0 || index >= global_argc) return NULL;
    return global_argv[index];
}

int datap_int(int index) {
    if (index < 0 || index >= global_argc) return -1;
    return atoi(global_argv[index]);
}